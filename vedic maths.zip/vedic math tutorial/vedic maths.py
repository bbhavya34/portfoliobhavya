import tkinter as tk
from PIL import ImageTk, Image
import random


def practice_1():
    practice_window = tk.Toplevel(root)
    practice_window.geometry("400x400")
    practice_window.iconbitmap("education-math_icon.ico")
    practice_window.title("Practice question")
    practice_window.configure(bg="#047BD5")
    practice_window.resizable(False, False)

    def show_question():
        global num1, num2, timer_active, question_id
        num1 = random.randint(1, 500)
        tup=(9,99,999,9999)
        num2 = random.choice(tup)
        question_label.config(text=f"What is {num1} x {num2}?", bg="#047BD5")
        answer_entry.delete(0, tk.END)
        answer_entry.focus()
        timer_active = True
        start_timer()
        question_id = practice_window.after(60000, show_question)

    def check_answer():
        global timer_active, question_id
        if not timer_active:
            return

        try:
            user_answer = int(answer_entry.get())
        except ValueError:
            result_label.config(text="Please enter a valid number.", bg="#047BD5")
            return

        if user_answer == num1 * num2:
            result_label.config(text="Correct!", background="#047BD5")
            practice_window.after_cancel(question_id)
            show_question()
        else:
            result_label.config(text="Incorrect. Please try again.", bg="#047BD5")
        answer_entry.delete(0, tk.END)
        answer_entry.focus()

    def start_timer():
        global timer_active, seconds
        seconds = 60
        countdown()

    def countdown():
        global timer_active, seconds, question_id
        if timer_active and seconds > 0:
            time_label.config(text=f"Time left: {seconds} seconds", bg="#047BD5")
            seconds -= 1
            time_label.after(1000, countdown)
        else:
            timer_active = False
            time_label.config(text="Time's up!",background="#047BD5")
            result_label.config(text="Please try again.", bg="#047BD5")
            answer_entry.delete(0, tk.END)
            answer_entry.focus()
            practice_window.after_cancel(question_id)

    # Create the widgets
    question_label = tk.Label(practice_window, font=("Arial", 16), pady=20, bg="#047BD5")
    answer_entry = tk.Entry(practice_window, font=("Arial", 16))
    submit_button = tk.Button(practice_window, text="Submit", font=("Arial", 16),bg="Green", command=check_answer)
    result_label = tk.Label(practice_window, font=("Arial", 16), pady=20, bg="#047BD5")
    start_button = tk.Button(practice_window, text="Start Quiz", bg="green",font=("Arial", 16), command=show_question)
    time_label = tk.Label(practice_window, font=("Arial", 16), background="#047BD5")

    # Pack the widgets
    question_label.pack()
    answer_entry.pack()
    submit_button.pack()
    result_label.pack()
    start_button.pack()
    time_label.pack()
    


def practice_2():
    practice_2_window= tk.Toplevel(root)
    practice_2_window.geometry("400x400")
    practice_2_window.iconbitmap("education-math_icon.ico")
    practice_2_window.title("Practice question")
    practice_2_window.configure(bg="#047BD5")
    practice_2_window.resizable(False,False)

    def show_question_1():
        global num3, num4, timer_active_1, question_id_1
        num3 = random.randint(91, 109)
        num4 = random.randint(91, 109)
        question_label_1.config(text=f"What is {num3} x {num4}?", bg="#047BD5")
        answer_entry_1.delete(0, tk.END)
        answer_entry_1.focus()
        timer_active_1 = True
        start_timer_1()
        question_id_1 = practice_2_window.after(60000, show_question_1)

    def check_answer_1():
        global timer_active_1, question_id_1
        if not timer_active_1:
            return

        try:
            user_answer_1 = int(answer_entry_1.get())
        except ValueError:
            result_label_1.config(text="Please enter a valid number.",bg="#047BD5")
            return

        if user_answer_1 == num3 * num4:
            result_label_1.config(text="Correct!",bg="#047BD5")
            practice_2_window.after_cancel(question_id_1)
            show_question_1()
        else:
            result_label_1.config(text="Incorrect. Please try again.", bg="#047BD5")
        answer_entry_1.delete(0, tk.END)
        answer_entry_1.focus()

    def start_timer_1():
        global timer_active_1, seconds_1
        seconds_1 = 60
        countdown_1()

    def countdown_1():
        global timer_active_1, seconds_1, question_id_1
        if timer_active_1 and seconds_1 > 0:
            time_label_1.config(text=f"Time left: {seconds_1} seconds", bg="#047BD5")
            seconds_1 -= 1
            time_label_1.after(1000, countdown_1)
        else:
            timer_active_1 = False
            time_label_1.config(text="Time's up!",bg="#047BD5")
            result_label_1.config(text="Please try again.",bg="#047BD5")
            answer_entry_1.delete(0, tk.END)
            answer_entry_1.focus()
            practice_2_window.after_cancel(question_id_1)

    # Create the widgets
    question_label_1 = tk.Label(practice_2_window, font=("Arial", 16), pady=20, bg="#047BD5")
    answer_entry_1 = tk.Entry(practice_2_window, font=("Arial", 16))
    submit_button_1 = tk.Button(practice_2_window, text="Submit",bg="green", font=("Arial", 16), command=check_answer_1)
    result_label_1 = tk.Label(practice_2_window, font=("Arial", 16), pady=20,bg="#047BD5")
    start_button_1 = tk.Button(practice_2_window, text="Start Quiz",bg="green", font=("Arial", 16), command=show_question_1)
    time_label_1 = tk.Label(practice_2_window, font=("Arial", 16),bg="#047BD5")

    # Pack the widgets
    question_label_1.pack()
    answer_entry_1.pack()
    submit_button_1.pack()
    result_label_1.pack()
    start_button_1.pack()
    time_label_1.pack()


def practice_3():
    practice_3_window= tk.Toplevel(root)
    practice_3_window.geometry("400x400")
    practice_3_window.iconbitmap("education-math_icon.ico")
    practice_3_window.title("Practice question")
    practice_3_window.configure(bg="#047BD5")
    practice_3_window.resizable(False,False)

    def show_question_2():
        global num5, timer_active_2, question_id_2
        tup2= (5,15,25,35,45,55,65,75,85,95)
        my_range= range(91,110)
        new_tup= tup2+ tuple(my_range)
        num5 = random.choice(new_tup)
        question_label_2.config(text=f"What is {num5} x {num5}?",bg="#047BD5")
        answer_entry_2.delete(0, tk.END)
        answer_entry_2.focus()
        timer_active_2 = True
        start_timer_2()
        question_id_2 = practice_3_window.after(60000, show_question_2)

    def check_answer_2():
        global timer_active_2, question_id_2
        if not timer_active_2:
            return

        try:
            user_answer_2 = int(answer_entry_2.get())
        except ValueError:
            result_label_2.config(text="Please enter a valid number.",bg="#047BD5")
            return

        if user_answer_2 == num5 * num5:
            result_label_2.config(text="Correct!",bg="#047BD5")
            practice_3_window.after_cancel(question_id_2)
            show_question_2()
        else:
            result_label_2.config(text="Incorrect. Please try again.",bg="#047BD5")
        answer_entry_2.delete(0, tk.END)
        answer_entry_2.focus()

    def start_timer_2():
        global timer_active_2, seconds_2
        seconds_2 = 60
        countdown_2()

    def countdown_2():
        global timer_active_2, seconds_2, question_id_2
        if timer_active_2 and seconds_2 > 0:
            time_label_2.config(text=f"Time left: {seconds_2} seconds",bg="#047BD5")
            seconds_2 -= 1
            time_label_2.after(1000, countdown_2)
        else:
            timer_active_2 = False
            time_label_2.config(text="Time's up!",bg="#047BD5")
            result_label_2.config(text="Please try again.",bg="#047BD5")
            answer_entry_2.delete(0, tk.END)
            answer_entry_2.focus()
            practice_3_window.after_cancel(question_id_2)

    # Create the widgets
    question_label_2 = tk.Label(practice_3_window, font=("Arial", 16), pady=20,bg="#047BD5")
    answer_entry_2 = tk.Entry(practice_3_window, font=("Arial", 16))
    submit_button_2 = tk.Button(practice_3_window, text="Submit", font=("Arial", 16), command=check_answer_2, bg="green")
    result_label_2 = tk.Label(practice_3_window, font=("Arial", 16), pady=20,bg="#047BD5")
    start_button_2 = tk.Button(practice_3_window, text="Start Quiz", font=("Arial", 16), command=show_question_2,bg="green")
    time_label_2 = tk.Label(practice_3_window, font=("Arial", 16),bg="#047BD5")

    # Pack the widgets
    question_label_2.pack()
    answer_entry_2.pack()
    submit_button_2.pack()
    result_label_2.pack()
    start_button_2.pack()
    time_label_2.pack()



# Multiplication with 9999 window 
def show_multiplication_999():
    # create a new window to show the tutorial for multiplication of 9999...
    multiplication_999_window = tk.Toplevel(root)
    multiplication_999_window.geometry("1000x650")
    multiplication_999_window.iconbitmap("education-math_icon.ico")
    multiplication_999_window.title("Multiplication of 9999... in just 5 seconds")
    multiplication_999_window.configure(bg="light green")
    multiplication_999_window.resizable(False,False)
    

    # Create a Frame widget to hold the Text widget and scrollbar
    
    frame = tk.Frame(multiplication_999_window)
    frame.config(width=800, height=800)

    label= tk.Label(frame, text = "Multiplication 999... in just 5 seconds")
    label.config(font =("Times", 25,"bold"),bg="light green")
    label.pack(side="top", fill="x")
    #tutorial
    file1= open("multiplication_999.txt","r")
    tutorial= file1.read()
    # Create a Text widget inside the frame and insert some text
    text = tk.Text(frame,wrap=tk.NONE,font=("Courier New",14, "bold"), fg="black", background="light green")
    text.insert(tk.END,tutorial)
    file1.close()

# Set the state of the Text widget to DISABLED
    text.config(state=tk.DISABLED)
    btn3= tk.Button(multiplication_999_window, text="Practice ", height=2,width=15, bg="green", fg="white", command=practice_1)
    btn3.pack(side="bottom", pady=20)
# Create a Scrollbar widget and attach it to the Text widget
    scrollbary = tk.Scrollbar(frame,orient="vertical", command=text.yview, bg="light green")
    text.config(yscrollcommand=scrollbary.set)
    scrollbarx = tk.Scrollbar(frame,orient="horizontal" ,command=text.xview, bg= "light green")
    text.config(xscrollcommand=scrollbarx.set, padx=12, pady=3)

# Pack both the Text and Scrollbar widgets inside the Frame widget
    text.pack(side="left",fill="both", expand=True)
    scrollbary.pack(side="right", fill="y" )
    scrollbarx.pack(side="bottom", fill="x")

# Pack the Frame widget wherever you want to display it
    frame.pack()
    
# Multiplication with near base window 
def show_multiplication_near_base():
    # create a new window to show the tutorial for multiplication of 9999...
    multiplication_near_bases_window = tk.Toplevel(root)
    multiplication_near_bases_window.iconbitmap("education-math_icon.ico")
    multiplication_near_bases_window.geometry("1000x650")
    multiplication_near_bases_window.title("Show multiplication near base")
    multiplication_near_bases_window.resizable(False,False)
    multiplication_near_bases_window.configure(bg="light green")
    file2= open("multiplication_near_bases.txt","r")
    tutorial_1= file2.read()
    # Create a Frame widget to hold the Text widget and scrollbar
    
    frame_1 = tk.Frame(multiplication_near_bases_window)
    frame_1.config(width=800, height=800)

    label_1= tk.Label(frame_1, text = "Multiplication 999... in just 5 seconds")
    label_1.config(font =("Times", 25,"bold"),bg="light green")
    label_1.pack(side="top", fill="x")


    # Create a Text widget inside the frame and insert some text
    text_1 = tk.Text(frame_1,wrap=tk.NONE,font=("Courier New",14, "bold"), fg="black", background="light green")
    text_1.insert(tk.END,tutorial_1)
    btn1 = tk.Button(multiplication_near_bases_window, text="Practice ", height=2,width=15, bg="green", fg="white", command=practice_2)
    btn1.pack(side="bottom", pady=20)
# Set the state of the Text widget to DISABLED
    text_1.config(state=tk.DISABLED)

# Create a Scrollbar widget and attach it to the Text widget
    scrollbary_1 = tk.Scrollbar(frame_1,orient="vertical", command=text_1.yview)
    text_1.config(yscrollcommand=scrollbary_1.set)

    scrollbarx_1= tk.Scrollbar(frame_1,orient="horizontal" ,command=text_1.xview)
    text_1.config(xscrollcommand=scrollbarx_1.set)

# Pack both the Text and Scrollbar widgets inside the Frame widget
    text_1.pack(side="left",fill="both", expand=True)
    scrollbary_1.pack(side="right", fill="y")
    scrollbarx_1.pack(side="bottom", fill="x")

# Pack the Frame widget wherever you want to display it
    frame_1.pack()
    file2.close()
# Intreasting square window
def intresting_square():
    # create a new window to show the tutorial for multiplication of 9999...
    intresting_square_window = tk.Toplevel(root)
    intresting_square_window.geometry("1000x650")
    intresting_square_window.resizable(False,False)
    intresting_square_window.title("intresting square")
    intresting_square_window.configure(bg="light green")
    intresting_square_window.iconbitmap("education-math_icon.ico")
    # Create a Frame widget to hold the Text widget and scrollbar
    
    frame_2= tk.Frame(intresting_square_window)
    frame_2.config(width=800, height=800)

    label_2= tk.Label(frame_2, text = "Intresting square")
    label_2.config(font =("Times", 25,"bold"),bg="light green")
    label_2.pack(side="top", fill="x")
    file3= open("intreasting_square.txt","r")
    tutorial_2= file3.read()

     # Create a Text widget inside the frame and insert some text
    text_2 = tk.Text(frame_2,wrap=tk.NONE,font=("Courier New",14, "bold"), fg="black", background="light green")
    text_2.insert(tk.END,tutorial_2)
    btn = tk.Button(intresting_square_window, text="Practice ", height=2,width=15, bg="green", fg="white", command=practice_3)
    btn.pack(side="bottom", pady=20)
# Set the state of the Text widget to DISABLED
    text_2.config(state=tk.DISABLED)

# Create a Scrollbar widget and attach it to the Text widget
    scrollbary_2 = tk.Scrollbar(frame_2,orient="vertical", command=text_2.yview)
    text_2.config(yscrollcommand=scrollbary_2.set)

    scrollbarx_2= tk.Scrollbar(frame_2,orient="horizontal" ,command=text_2.xview)
    text_2.config(xscrollcommand=scrollbarx_2.set(10,100))
# Pack both the Text and Scrollbar widgets inside the Frame widget
    text_2.pack(side="left",fill="both", expand=True)
    scrollbary_2.pack(side="left", fill="y")
    scrollbarx_2.pack(side="bottom", fill="x")

# Pack the Frame widget wherever you want to display it
    frame_2.pack()
    file3.close()
def show_options():
     #a new window to show the options
    options_window = tk.Toplevel(root)
    options_window.geometry("700x500")
    
    options_window.title("Vedic Maths Options")
    options_window.configure(bg="#F7A200")
    options_window.resizable(False, False)
    options_window.iconbitmap("education-math_icon.ico")
    
    # label for the options
    options_label = tk.Label(options_window, text="Choose something that you want to learn")
    options1_label = tk.Label(options_window, text="Basic topic of vedic mathematics are:")
    options_label.config(font=("Times",20,"bold"),fg="#212F3C",bg="#F7A200")
    options1_label.config(font=("Times",20,"bold"),fg="#212F3C",bg="#F7A200")
    options_label.pack(pady=15)
    options1_label.pack(pady=15)
    
    # create buttons for the options
    multiplication_999_button = tk.Button(options_window, text="Multiplications with 99999... in less than 5 seconds",height=2, bg="#F7A200", fg="white", command=show_multiplication_999)
    multiplication_999_button.config(font=("MS Sans Serif", 15), bg="green", fg="white")
    multiplication_999_button.pack(pady=10)
    
    multiplication_bases_button = tk.Button(options_window, text="Multiplication of numbers near the bases", height=2, bg="#F7A200", fg="white", command=show_multiplication_near_base)
    multiplication_bases_button.config(font=("MS Sans Serif", 15), bg="green", fg="white")
    multiplication_bases_button.pack(pady=10)

    intresting_square_button = tk.Button(options_window, text="Intresting squares", height=2, bg="#F7A200", fg="white", command=intresting_square)
    intresting_square_button.config(font=("MS Sans Serif", 15), bg="green", fg="white")
    intresting_square_button.pack(pady=10)

    
#main window
root = tk.Tk()
root.geometry("1200x700")
root.title("Vedic maths tutorial!")
root.iconbitmap("education-math_icon.ico")
root.resizable(True,True)
root.configure(bg="#FFA500")


#background

img =Image.open('bg_main_window(2).jpg')
resized_img=img.resize((1200+500,1200+500))
bg = ImageTk.PhotoImage(resized_img)
# Add image
label = tk.Label(root, image=bg)
label.place(x = 0,y = 0)
# title label
title_label = tk.Label(root, text="WELCOME TO VEDIC MATHS TUTORIAL")
title_label.config(font=("Times", 35 ,"bold"))
title_label.pack(pady=80)

# label for text
tutorial_label = tk.Label(root, text="In this tutorial, you will learn how to do fast ", fg="black",)
tutorial_label.config(font=("Arial", 15,"italic"))
tutorial_label.pack(pady=(20,0))

tutorial_label = tk.Label(root, text="calculations using Vedic Maths techniques", fg="black",)
tutorial_label.config(font=("Arial", 15,"italic"))
tutorial_label.pack()

# button to start the tutorial
start_button = tk.Button(root, text="Start Tutorial", padx=10, pady=10, bg="green", fg="white", command=show_options)
start_button.config(font=("MS Sans Serif",20,"bold"))
start_button.pack(pady=80)

# label for the footer text
footer_label = tk.Label(root, text="© 2023 Vedic Maths Tutorial. All rights reserved.")
footer_label.config(font=("switzer", 10, "italic"))
footer_label.pack(side="bottom", pady=20)

# Image source
footer_2_label = tk.Label(root, text="Image source- www.vectorstock.com")
footer_2_label.config(font=("switzer", 7, "italic"), )
footer_2_label.pack(side="bottom", pady=5)

#running the program
root.mainloop()