# Write a python program to take 3 numbers from the user and display product of those numbers.

x= int(input("Enter a number: "))
y= int(input("Enter a number: "))
z= int(input("Enter a number: "))

product= x*y*z
print("Product of the numbers are:",product)