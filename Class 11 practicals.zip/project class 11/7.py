# Write a program in Python to convert a given temperature from celcius to fahrenheit.

c= int(input("Enter temprature in celcius: "))
f= (1.8*c)+32

print(c, "degree celcius =", f, "degree farenheit")