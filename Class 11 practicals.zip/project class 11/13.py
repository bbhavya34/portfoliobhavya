# Write a menu driven program in Python to print the given patterns (star,letters, number).
# (1) Star pattern
x= int(input("Enter a number: "))
if x==1:
    a= int(input("Enter a numbber upto which you want to print pattern"))
    for i in range(0,a):
        for j in range(0, i+1):
            print('*', end="")
        print("")


elif x==2:
    a= int(input("Enter a numbber upto which you want to print pattern"))
    str= "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for i in range(0,a):
        for j in range(0, i+1):
            print(str[j], end="")
        print("")

if x==3:

    a= int(input("Enter a numbber upto which you want to print pattern"))
    for i in range(0,A):
        for j in range(0, i+1):
            print(j, end="")
        print("")
