# Write a python program to take radius of a circle and print perimeter and area of the circle.

r= int(input("Enter a number: "))

area= round(3.14*(r)**2)
perimeter= 2*(3.14)*r

print("Area of circle is:", area)
print("Perimeter of circle is:", perimeter)