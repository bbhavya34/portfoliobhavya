# Write a menu driven program in Python to reverse the list, find the sum of elements of list, and find average and standard deviation.
prompt= int(input("1 for reversed list , 2 for sum of list 3 for average of list 4 for standard deviation "))
a = int(input("Enter the maximum no. of element: "))
list = []

for i in range(a):
  x = int(input("Enter an element. "))
  list.append(x)
print("The original list : " + str(list))
b = sum(list)
mean = b / a
variation = sum([((x - mean)**2) for x in list]) / a
deviation = variation**0.5


if prompt==1:
  print("reversed list is:", list[::-1])

elif prompt==2:
  print("Sum of the list is:", b)
elif prompt==3:
  print("Average of the list is:", mean)
elif prompt==4:
  print("Standard deviation of ths list is  is : " + str(deviation))

else:
  print("Wrong input")