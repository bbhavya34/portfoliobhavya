# Write a python program to show all possible data type available in python.

a= 1                  #integer
b=2.0                 #float
c=5+4j                #complex
d= "Hello world"      #string
e= [1,2,3,4,5]        #list
f={a: 'A'}            #dictionary
g= (1,2,3,4,5)        #tuple

print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))
print(type(f))
print(type(g))
print(type(True))