# Write a Python program to calculate the product, multiplying all the numbers of a given tuple.

tup= (1,2,3,4,5,6,7,8,9,3,233,4,2,3,1,2,3,4)
product= 1

for i in tup:
    product= product*i
print("Product of the tuple is:",product)

