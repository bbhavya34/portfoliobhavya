# Design a simple calculator that read various operands and operators from user and perform mathematical operations.
from math import sqrt, pow
from statistics import mean
while True:
    # a= int(input("Enter number:"))
    # b= int(input("Enter number:"))
    x= input("enter operator as *, / , +, - , sqrt, pow, mean: ")
    meanx= []
    if x=="*":
        a= int(input("Enter number:"))
        b= int(input("Enter number:"))
        print("Product is:", a*b)
    elif x=="/":
        a= int(input("Enter number:"))
        b= int(input("Enter number:"))
        print("division is:", a/b)
    elif x=="+":
        a= int(input("Enter number:"))
        b= int(input("Enter number:"))
        print("sum is:", a+b)
    elif x=="-":
        a= int(input("Enter number:"))
        b= int(input("Enter number:"))
        print("subtraction is:", a-b)
    elif x=="sqrt":
        a= int(input("Enter number:"))
        b= int(input("Enter number:"))
        print("square root of ",a, "is:", sqrt(a), "and","square root of ",b,"is", sqrt(b) )
    elif x=="pow":
        a= int(input("Enter number:"))
        b= int(input("Enter number:"))
        print(a, "raise to the power" ,b ,"is:", pow(a,b))
    elif x=="mean":
        el= int(input("Enter how many elements are there in list?: "))
        for i in range(el):
            element=int(input("Enter element: "))
            meanx.append(element)
        meany= mean(meanx)
        print("Mean of the given data is", meany)

    else:
        print("Wrong input")

    str =input("Press Enter KEY to continue and 0 key to exit ")
    if str=="0":
        break